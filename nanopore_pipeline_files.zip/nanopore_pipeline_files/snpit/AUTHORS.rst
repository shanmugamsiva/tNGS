=======
Credits
=======

Development Lead
----------------

* Sam Lipworth <samuel.lipworth@medsci.ox.ac.uk>
* Philip Fowler <philip.fowler@ndm.ox.ac.uk>

Contributors
------------

* Michael B. Hall <michael.hall@ebi.ac.uk>