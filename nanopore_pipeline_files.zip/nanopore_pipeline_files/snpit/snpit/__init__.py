#! /usr/bin/env python3

from .snpit import SnpIt
