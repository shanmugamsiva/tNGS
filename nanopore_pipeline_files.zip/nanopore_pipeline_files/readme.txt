Install Dependencies
    Minimap2, Samtools, and Bcftools must be installed before executing the tNGS pipeline.

Run the Pipeline
    The tNGS pipeline is executed using the nanopore_pipeline.sh script. The script should be executed outsid the nanopore_pipelie folder

Generate Variant Output
    The pipeline produces a Variant Call Format (VCF) file upon completion.

Annotation and Drug-Resistance Prediction
    The generated VCF file is annotated and analyzed for drug-resistance prediction by comparison with the Indian Mutation Catalogue (Version 2).

Reference Database
    The Indian Mutation Catalogue (Version 2) is publicly available at:
    https://www.nirt.res.in/pdf/mutation_catalogue_v2.pdf.
